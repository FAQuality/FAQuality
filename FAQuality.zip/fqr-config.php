<?php
return [
    'email_asunto' => 'Gracias por contactar con nosotros',
    'email_cuerpo' => 'Estamos agradecidos porque se tome su tiempo contactando con nosotros. Le responderemos en breve.'
];